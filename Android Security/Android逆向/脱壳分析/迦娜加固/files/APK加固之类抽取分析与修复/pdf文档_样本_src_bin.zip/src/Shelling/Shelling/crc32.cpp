#include "stdafx.h"
#include "crc32.h"
#include <windows.h>

unsigned long crc32(unsigned long crc, const unsigned char *buf, unsigned len)
{
	if (NULL == buf) 
		return 0UL;

	crc = crc ^ 0xffffffffUL;

	unsigned n = 0;
	for (n = 0; n < len; n++)
	{
		crc = crc_table[(crc ^ buf[n]) & 0xff] ^ (crc >> 8);
	}
	return crc ^ 0xffffffffUL;
}