// FindDexCode.cpp : Defines the entry point for the console application.
//
#pragma once
#include "stdafx.h"
#include "dexFile.h"
#include <windows.h>
#include <stdio.h>
#include <assert.h>
#include "Dec.h"


//DexFile* pDexFile;
HANDLE hMapFile;
HANDLE hFile;
LPVOID lpMapAddress;
DWORD dexsize;

DexFile gDexFile;
u1* gCodeData = NULL;

void initDex(char* DexFileName)
{

	hFile = CreateFile(DexFileName, 
		GENERIC_READ | GENERIC_WRITE,
		0, 
		NULL,
		OPEN_EXISTING, 
		FILE_ATTRIBUTE_NORMAL, 
		NULL);
	
	if (hFile == INVALID_HANDLE_VALUE)
	{
		printf("hFile is NULL\n");
		printf("Target file is %s\n", 
			DexFileName);
		return ;
	}
	dexsize = GetFileSize(hFile, NULL);
	hMapFile = CreateFileMapping( hFile,         // current file handle
		NULL,           // default security
		PAGE_READWRITE, // read/write permission
		0,              // size of mapping object, high
		dexsize,  // size of mapping object, low
		NULL);          // name of mapping object
	
	if (hMapFile == NULL) 
	{
		printf("hMapFile is NULL: last error: %d\n", GetLastError() );
		return;
	}
	
	// Map the view and test the results.
	
	lpMapAddress = MapViewOfFile(hMapFile,            // handle to 
		// mapping object
		FILE_MAP_ALL_ACCESS, // read/write 
		0,                   // high-order 32 
		// bits of file 
		// offset
		0,      // low-order 32
		// bits of file 
		// offset
		dexsize);      // number of bytes
	// to map
	if (lpMapAddress == NULL) 
	{
		printf("lpMapAddress is NULL: last error: %d\n", GetLastError());
		return ;
	}
 // pDexFile = new DexFile;

  void *dexBase = lpMapAddress;


  DexHeader *dexHeader = (DexHeader *)dexBase;
  
  gDexFile.baseAddr   = (u1*)dexBase;
  gDexFile.pHeader    = dexHeader;
  gDexFile.pStringIds = (DexStringId*)((u4)dexBase+dexHeader->stringIdsOff);
  gDexFile.pTypeIds   = (DexTypeId*)((u4)dexBase+dexHeader->typeIdsOff);
  gDexFile.pMethodIds = (DexMethodId*)((u4)dexBase+dexHeader->methodIdsOff);
  gDexFile.pFieldIds  = (DexFieldId*)((u4)dexBase+dexHeader->fieldIdsOff);
  gDexFile.pClassDefs = (DexClassDef*)((u4)dexBase+dexHeader->classDefsOff);
  gDexFile.pProtoIds  = (DexProtoId*)((u4)dexBase+dexHeader->protoIdsOff);

}


void Uninit()
{
	UnmapViewOfFile(lpMapAddress);
	CloseHandle(hFile);
	if (NULL != gCodeData)
	{
		free(gCodeData);
		gCodeData = NULL;
	}
}

//-------------------------------------------------

static void getAccessFlags(char *buf, int flags)
{
    if((flags & ACC_PUBLIC) != 0)   strcat(buf, "public ");
    if((flags & ACC_PRIVATE) != 0)   strcat(buf, "private ");
    if((flags & ACC_PROTECTED) != 0)   strcat(buf, "protected ");    
    if((flags & ACC_STATIC) != 0)   strcat(buf, "static ");    
    if((flags & ACC_FINAL) != 0)   strcat(buf, "final ");    
    if((flags & ACC_SYNCHRONIZED) != 0)   strcat(buf, "synchronized ");    
    if((flags & ACC_SUPER) != 0)   strcat(buf, "super ");    
    if((flags & ACC_VOLATILE) != 0)   strcat(buf, "volatile ");    
    if((flags & ACC_BRIDGE) != 0)   strcat(buf, "bridge ");    
    if((flags & ACC_TRANSIENT) != 0)   strcat(buf, "transient ");    
    if((flags & ACC_VARARGS) != 0)   strcat(buf, "varargs ");    
    if((flags & ACC_NATIVE) != 0)   strcat(buf, "native ");    
    if((flags & ACC_INTERFACE) != 0)   strcat(buf, "interface ");    
    if((flags & ACC_ABSTRACT) != 0)   strcat(buf, "abstract ");    
    if((flags & ACC_STRICT) != 0)   strcat(buf, "strict ");    
    if((flags & ACC_SYNTHETIC) != 0)   strcat(buf, "synthetic ");    
    if((flags & ACC_ANNOTATION) != 0)   strcat(buf, "annotation ");    
    if((flags & ACC_ENUM) != 0)   strcat(buf, "enum ");    
    if((flags & ACC_CONSTRUCTOR) != 0)   strcat(buf, "constructor ");    
    if((flags & ACC_DECLARED_SYNCHRONIZED) != 0)   strcat(buf, "synchronize ");    
}

static int readUnsignedLeb128(const u1** pStream) {
    const u1* ptr = *pStream;
    int result = *(ptr++);

    if (result > 0x7f) {
        int cur = *(ptr++);
        result = (result & 0x7f) | ((cur & 0x7f) << 7);
        if (cur > 0x7f) {
            cur = *(ptr++);
            result |= (cur & 0x7f) << 14;
            if (cur > 0x7f) {
                cur = *(ptr++);
                result |= (cur & 0x7f) << 21;
                if (cur > 0x7f) {
                    /*
                     * Note: We don't check to see if cur is out of
                     * range here, meaning we tolerate garbage in the
                     * high four-order bits.
                     */
                    cur = *(ptr++);
                    result |= cur << 28;
                }
            }
        }
    }

    *pStream = ptr;
    return result;
}


static  DexCode* dexGetCode(DexFile* pDexFile,
    const DexMethod* pDexMethod)
{
    if (pDexMethod->codeOff == 0)
        return NULL;
    return (DexCode*) (pDexFile->baseAddr + pDexMethod->codeOff);
}

/* return the ClassDef with the specified index */
static const DexClassDef* dexGetClassDef(const DexFile* pDexFile, u4 idx) {
    assert(idx < pDexFile->pHeader->classDefsSize);
    return &pDexFile->pClassDefs[idx];
}


/* Read the header of a class_data_item without verification. This
 * updates the given data pointer to point past the end of the read
 * data. */
static void dexReadClassDataHeader(const u1** pData,
        DexClassDataHeader *pHeader) {
    pHeader->staticFieldsSize = readUnsignedLeb128(pData);
    pHeader->instanceFieldsSize = readUnsignedLeb128(pData);
    pHeader->directMethodsSize = readUnsignedLeb128(pData);
    pHeader->virtualMethodsSize = readUnsignedLeb128(pData);
}

/* Read an encoded_field without verification. This updates the
 * given data pointer to point past the end of the read data.
 *
 * The lastIndex value should be set to 0 before the first field in
 * a list is read. It is updated as fields are read and used in the
 * decode process.
 */
static void dexReadClassDataField(const u1** pData, DexField* pField,
        u4* lastIndex) {
    u4 index = *lastIndex + readUnsignedLeb128(pData);

    pField->accessFlags = readUnsignedLeb128(pData);
    pField->fieldIdx = index;
    *lastIndex = index;
}

/* Read an encoded_method without verification. This updates the
 * given data pointer to point past the end of the read data.
 *
 * The lastIndex value should be set to 0 before the first method in
 * a list is read. It is updated as fields are read and used in the
 * decode process.
 */
static void dexReadClassDataMethod(const u1** pData, DexMethod* pMethod,
        u4* lastIndex) {
    u4 index = *lastIndex + readUnsignedLeb128(pData);

    pMethod->accessFlags = readUnsignedLeb128(pData);
    pMethod->codeOff = readUnsignedLeb128(pData);
    pMethod->methodIdx = index;
    *lastIndex = index;
}



static char *getString(const DexFile *dexFile, int id)
{
    return (char *)(dexFile->baseAddr + dexFile->pStringIds[id].stringDataOff+1);
}

static int getTypeIdStringId(const DexFile *dexFile, int id)
{
    const DexTypeId *typeId = dexFile->pTypeIds;
    return typeId[id].descriptorIdx;
}
#define getTpyeIdString(dexFile, id) getString((dexFile), getTypeIdStringId((dexFile),(id)))

static u1 *getClassDataPtr(const DexFile *dexFile, int idx)
{
    return (u1 *)(dexFile->baseAddr + dexFile->pClassDefs[idx].classDataOff);
}

static void dumpDexHeader(DexHeader *header)
{
    printf("[Dex Header] headerSize:0x%08lx fileSize:0x%08lx", header->headerSize, header->fileSize);
    printf("[Dex Header] linkSize:0x%08lx linkOff:0x%08lx mapOff:0x%08lx", header->linkSize, header->linkOff, header->mapOff);
    printf("[Dex Header] StringIds   size:0x%08lx offset:0x%08lx", header->stringIdsSize, header->stringIdsOff);
    printf("[Dex Header] TypeIds     size:0x%08lx offset:0x%08lx", header->typeIdsSize, header->typeIdsOff);
    printf("[Dex Header] ProtoIds    size:0x%08lx offset:0x%08lx", header->protoIdsSize, header->protoIdsOff);
    printf("[Dex Header] FieldIds    size:0x%08lx offset:0x%08lx", header->fieldIdsSize, header->fieldIdsOff);
    printf("[Dex Header] MethodIds   size:0x%08lx offset:0x%08lx", header->methodIdsSize, header->methodIdsOff);
    printf("[Dex Header] ClassDefs   size:0x%08lx offset:0x%08lx", header->classDefsSize, header->classDefsOff);
    printf("[Dex Header] Data        size:0x%08lx offset:0x%08lx", header->dataSize, header->dataOff);
}

static void dumpDexStrings(const DexFile *dexFile)
{
    int i =0;
    char *str;
    int count = dexFile->pHeader->stringIdsSize;

    for(i=0; i<count; i++){
        str = (char *)(dexFile->baseAddr + dexFile->pStringIds[i].stringDataOff);
        printf("[Strings] id=%d [%d]:%s", i, str[0], str+1);
    }
}


static void dumpDexTypeIds(const DexFile *dexFile)
{
    const DexTypeId *typeId = dexFile->pTypeIds;
    int count = dexFile->pHeader->typeIdsSize;

    for(int i=0; i<count; i++){
        printf("[types] [%d] %s",  i, getString(dexFile, typeId[i].descriptorIdx));
    }
}

static void dumpFieldIds(const DexFile *dexFile)
{
    const DexFieldId *pfield = dexFile->pFieldIds;
    int count = dexFile->pHeader->fieldIdsSize;

    for(int i=0; i<count; i++){
        printf("[field] %s -> %s %s",
            getTpyeIdString(dexFile, pfield[i].classIdx),
            getString(dexFile, pfield[i].nameIdx),
            getTpyeIdString(dexFile, pfield[i].typeIdx));
    }
}

static void dumpDexProtos(const DexFile *dexFile)
{
    char buffer[1024];
    const DexProtoId *proto = dexFile->pProtoIds;
    int count = dexFile->pHeader->protoIdsSize;
    DexTypeList *plist;

    for(int i=0; i<count; i++){
        sprintf(buffer, "[proto] %d  short:", i);
        strcat(buffer, getString(dexFile, proto[i].shortyIdx));
        strcat(buffer, " return:");
        strcat(buffer, getTpyeIdString(dexFile, proto[i].returnTypeIdx));

        if(proto[i].parametersOff == 0){
        	printf("%s", buffer);
        	continue;
        }
        strcat(buffer, " param:");
        plist = (DexTypeList *)(dexFile->baseAddr + proto[i].parametersOff);
        for(u4 j=0; j<plist->size; j++){
            strcat(buffer, getTpyeIdString(dexFile,  plist->list[j].typeIdx));
        }
        printf("%s", buffer);
    }
}

static void dumpClassDefines(const DexFile *dexFile)
{
    char buffer[1024];
    const DexClassDef* classdef = dexFile->pClassDefs;
    int count = dexFile->pHeader->classDefsSize;

    buffer[0] = 0;
    for(int i=0; i<count; i++){
        getAccessFlags(buffer, classdef[i].accessFlags);
        strcat(buffer, " class ");
        strcat(buffer, getTpyeIdString(dexFile, classdef[i].classIdx));

        strcat(buffer, " externds ");
        strcat(buffer, getTpyeIdString(dexFile, classdef[i].superclassIdx));
        strcat(buffer, " implements ");
        
        //strcat(buffer, getTpyeIdString(dexFile, classdef[i].interfacesOff);
        
        printf("%s", buffer);
    }

}

static void dumpMethodIds(const DexFile *dexFile)
{
    const DexMethodId *pmethod = dexFile->pMethodIds;
}


static int readAndVerifyUnsignedLeb128(const u1** pStream, const u1* limit,
        bool* okay) {
    const u1* ptr = *pStream;
    int result = readUnsignedLeb128(pStream);

    if (((limit != NULL) && (*pStream > limit))
            || (((*pStream - ptr) == 5) && (ptr[4] > 0x0f))) {
        *okay = false;
    }

    return result;
}

/* Helper for verification which reads and verifies a given number
 * of uleb128 values. */
static bool verifyUlebs(const u1* pData, const u1* pLimit, u4 count) {
    bool okay = true;
    u4 i;

    while (okay && (count-- != 0)) {
        readAndVerifyUnsignedLeb128(&pData, pLimit, &okay);
    }

    return okay;
}

/* Read and verify the header of a class_data_item. This updates the
 * given data pointer to point past the end of the read data and
 * returns an "okay" flag (that is, false == failure). */
static bool dexReadAndVerifyClassDataHeader(const u1** pData, const u1* pLimit,
        DexClassDataHeader *pHeader) {
    if (! verifyUlebs(*pData, pLimit, 4)) {
        return false;
    }

    dexReadClassDataHeader(pData, pHeader);
   /* printf("ClassHeader: field: s-%ld i-%ld method: d-%ld v-%ld", 
        pHeader->staticFieldsSize, pHeader->instanceFieldsSize,
        pHeader->directMethodsSize, pHeader->staticFieldsSize);*/
    return true;
}

/* Read and verify an encoded_field. This updates the
 * given data pointer to point past the end of the read data and
 * returns an "okay" flag (that is, false == failure).
 *
 * The lastIndex value should be set to 0 before the first field in
 * a list is read. It is updated as fields are read and used in the
 * decode process.
 *
 * The verification done by this function is of the raw data format
 * only; it does not verify that access flags or indices
 * are valid. */
static bool dexReadAndVerifyClassDataField(const u1** pData, const u1* pLimit,
        DexField* pField, u4* lastIndex) {
    if (! verifyUlebs(*pData, pLimit, 2)) {
        return false;
    }

    dexReadClassDataField(pData, pField, lastIndex);
    return true;
}

/* Read and verify an encoded_method. This updates the
 * given data pointer to point past the end of the read data and
 * returns an "okay" flag (that is, false == failure).
 *
 * The lastIndex value should be set to 0 before the first method in
 * a list is read. It is updated as fields are read and used in the
 * decode process.
 *
 * The verification done by this function is of the raw data format
 * only; it does not verify that access flags, indices, or offsets
 * are valid. */
static bool dexReadAndVerifyClassDataMethod(const u1** pData, const u1* pLimit,
        DexMethod* pMethod, u4* lastIndex) {
    if (! verifyUlebs(*pData, pLimit, 3)) {
        return false;
    }

    dexReadClassDataMethod(pData, pMethod, lastIndex);
    return true;
}

/* Read, verify, and return an entire class_data_item. This updates
 * the given data pointer to point past the end of the read data. This
 * function allocates a single chunk of memory for the result, which
 * must subsequently be free()d. This function returns NULL if there
 * was trouble parsing the data. If this function is passed NULL, it
 * returns an initialized empty DexClassData structure.
 *
 * The verification done by this function is of the raw data format
 * only; it does not verify that access flags, indices, or offsets
 * are valid. */
static DexClassData* dexReadAndVerifyClassData(const u1** pData, const u1* pLimit) {
    DexClassDataHeader header;
    u4 lastIndex;

    if (*pData == NULL) {
        DexClassData* result = (DexClassData*) malloc(sizeof(DexClassData));
        memset(result, 0, sizeof(*result));
        return result;
    }

    if (! dexReadAndVerifyClassDataHeader(pData, pLimit, &header)) {
        return NULL;
    }

    size_t resultSize = sizeof(DexClassData) +
        (header.staticFieldsSize * sizeof(DexField)) +
        (header.instanceFieldsSize * sizeof(DexField)) +
        (header.directMethodsSize * sizeof(DexMethod)) +
        (header.virtualMethodsSize * sizeof(DexMethod));

    DexClassData* result = (DexClassData*) malloc(resultSize);
    u1* ptr = ((u1*) result) + sizeof(DexClassData);
    bool okay = true;
    u4 i;

    if (result == NULL) {
        return NULL;
    }

    result->header = header;

    if (header.staticFieldsSize != 0) {
        result->staticFields = (DexField*) ptr;
        ptr += header.staticFieldsSize * sizeof(DexField);
    } else {
        result->staticFields = NULL;
    }

    if (header.instanceFieldsSize != 0) {
        result->instanceFields = (DexField*) ptr;
        ptr += header.instanceFieldsSize * sizeof(DexField);
    } else {
        result->instanceFields = NULL;
    }

    if (header.directMethodsSize != 0) {
        result->directMethods = (DexMethod*) ptr;
        ptr += header.directMethodsSize * sizeof(DexMethod);
    } else {
        result->directMethods = NULL;
    }

    if (header.virtualMethodsSize != 0) {
        result->virtualMethods = (DexMethod*) ptr;
    } else {
        result->virtualMethods = NULL;
    }

    lastIndex = 0;
    for (i = 0; okay && (i < header.staticFieldsSize); i++) {
        okay = dexReadAndVerifyClassDataField(pData, pLimit,
                &result->staticFields[i], &lastIndex);
    }

    lastIndex = 0;
    for (i = 0; okay && (i < header.instanceFieldsSize); i++) {
        okay = dexReadAndVerifyClassDataField(pData, pLimit,
                &result->instanceFields[i], &lastIndex);
    }

    lastIndex = 0;
    for (i = 0; okay && (i < header.directMethodsSize); i++) {
        okay = dexReadAndVerifyClassDataMethod(pData, pLimit,
                &result->directMethods[i], &lastIndex);
    }

    lastIndex = 0;
    for (i = 0; okay && (i < header.virtualMethodsSize); i++) {
        okay = dexReadAndVerifyClassDataMethod(pData, pLimit,
                &result->virtualMethods[i], &lastIndex);
    }

    if (! okay) {
        free(result);
        return NULL;
    }

    return result;
}

static void dumpDexClassDataMethod(DexFile *dexFile, DexClassData* classData)
{
    int idx = 0;
    DexMethod *method = NULL;
    const DexMethodId* methodId = NULL;

    method = classData->directMethods;
    methodId = dexFile->pMethodIds;
    
    for (int i = 0; i < (int) classData->header.directMethodsSize; i++) {
        idx = classData->directMethods[i].methodIdx;

        DexCode* pCode = dexGetCode(dexFile, &classData->directMethods[i]);
        if(pCode == NULL) continue;
        //ALOGD("      registers     : %d", pCode->registersSize);
       // ALOGD("      ins           : %d", pCode->insSize);
       // ALOGD("      outs          : %d", pCode->outsSize);
       // ALOGD("      insns size    : %d 16-bit code units", pCode->insnsSize);

        int a = 0;
        char buffer[256] = {0, 0};
        char tmp[32];
        for(u4 k=0; k<pCode->insnsSize; k++){
            sprintf(tmp, "%04x ", pCode->insns[k]);
            strcat(buffer, tmp);
            if(k%8 == 7){
            	printf("%s", buffer);
                buffer[0] = 0;
            }
        }
        printf("%s", buffer);
    }

    for (int i = 0; i < (int) classData->header.virtualMethodsSize; i++) {
        idx = classData->virtualMethods[i].methodIdx;
        printf("idx-%d [%06lx]: %s->%s", idx, classData->virtualMethods[i].codeOff,
            getTpyeIdString(dexFile, methodId[idx].classIdx), getString(dexFile, methodId[idx].nameIdx));

        const DexCode* pCode = dexGetCode(dexFile, &classData->virtualMethods[i]);
        if(pCode == NULL) continue;
        printf("      registers     : %d", pCode->registersSize);
        printf("      ins           : %d", pCode->insSize);
        printf("      outs          : %d", pCode->outsSize);
        printf("      insns size    : %ld 16-bit code units", pCode->insnsSize);
        printf("      insns at      : %x ", (int)(pCode->insns) - (int)dexFile->baseAddr);

        printf("%x %x %x %x", pCode->insns[0], pCode->insns[1], pCode->insns[2], pCode->insns[3]);

        int a = 0;
        char buffer[256] = {0, 0};
        char tmp[32];
        for(u4 k=0; k<pCode->insnsSize; k++){
            sprintf(tmp, "%04x ", pCode->insns[k]);
            strcat(buffer, tmp);
            if(k%8 == 7){
                printf("%s", buffer);
                buffer[0] = 0;
            }
        }
        printf("%s", buffer);

   }
}

const DexStringId* dexGetStringId(const DexFile* pDexFile, u4 idx) {
	return &pDexFile->pStringIds[idx];
}

const char* dexGetStringData(const DexFile* pDexFile,const DexStringId* pStringId) 
{
	const u1* ptr = pDexFile->baseAddr + pStringId->stringDataOff;

	return (const char*) ptr;
}

const char* dexStringById(const DexFile* pDexFile, u4 idx) {
	const DexStringId* pStringId = dexGetStringId(pDexFile, idx);
	return dexGetStringData(pDexFile, pStringId);
}


const DexMethodId* dexGetMethodId(const DexFile* pDexFile, u4 idx) {

	return &pDexFile->pMethodIds[idx];
}

void FixdexMethodInsns(DexFile *dexFile, const DexClassData*classData ,const char* className)
{
	int idx = 0;
	DexMethod *method = NULL;
	const DexMethodId* methodId = NULL;
	DexCode* code = NULL;
	const char* methodName;
	method = classData->directMethods;
	methodId = dexFile->pMethodIds;
	unsigned int CodeDataOffset = 0;
	u1 * tempCode = NULL;
	for (int i = 0; i < (int) classData->header.directMethodsSize; i++) {
		idx = classData->directMethods[i].methodIdx;

		methodId = dexGetMethodId(dexFile, idx);
		methodName = dexStringById(dexFile, methodId->nameIdx);

		DexCode* pCode = dexGetCode(dexFile, &classData->directMethods[i]);
		if (NULL == pCode)
		{
			continue;
		}
		//�ж��Ƿ�Ϊ������ķ���������Ǿ��޸�ָ��
		if ( (pCode->debugInfoOff > 0x1FFFFFFF) && (pCode->insns[0] == 0X00))
		{
			//�����ָ���ƫ��
			CodeDataOffset = pCode->debugInfoOff << 0x8;
			CodeDataOffset >>= 0x6;
			//����ָ��
			tempCode = DecCode(gCodeData+CodeDataOffset, pCode->insnsSize*sizeof(u2), pCode->debugInfoOff, gCodeData);
			//�޸�ָ��
			memcpy(pCode->insns, tempCode, (pCode->insnsSize)*sizeof(u2));
			pCode->debugInfoOff = 0x00;
			printf("�޸� %s ���е� %s �����ɹ�! ��С %X\n",className, methodName,pCode->insnsSize);
			if (NULL != tempCode)
			{
				free(tempCode);
				tempCode = NULL;
			}
		}
	}

	for (int i = 0; i < (int) classData->header.virtualMethodsSize; i++) {
		idx = classData->virtualMethods[i].methodIdx;

		methodId = dexGetMethodId(dexFile, idx);
		methodName = dexStringById(dexFile, methodId->nameIdx);

		DexCode* pCode = dexGetCode(dexFile, &classData->virtualMethods[i]);
		if (NULL == pCode)
		{
			continue;
		}
		//�ж��Ƿ�Ϊ������ķ���������Ǿ��޸�ָ��
		if ( (pCode->debugInfoOff > 0x1FFFFFFF) && (pCode->insns[0] == 0X00))
		{
			//�����ָ���ƫ��
			CodeDataOffset = pCode->debugInfoOff << 0x8;
			CodeDataOffset >>= 0x6;
			//����ָ��
			tempCode = DecCode(gCodeData+CodeDataOffset, pCode->insnsSize*sizeof(u2), pCode->debugInfoOff, gCodeData);
			//�޸�ָ��
			memcpy(pCode->insns, tempCode, (pCode->insnsSize)*sizeof(u2));
			pCode->debugInfoOff = 0x00;
			printf("�޸� %s ���е� %s �����ɹ�! ��С %X\n",className, methodName,pCode->insnsSize);
			if (NULL != tempCode)
			{
				free(tempCode);
				tempCode = NULL;
			}
		}
	}
	return;
}

void fixdexClassData()
{

	DexFile *dexFile = &gDexFile;

	char * Tag = "L";
	char * ClassTag = "Landroid/";

    const DexClassDef* classdef;
    u4 count = dexFile->pHeader->classDefsSize;

	printf("��DEX���� %d ����\n", count);

    const u1* pEncodedData = NULL;
    DexClassData* pClassData = NULL;
    const char *descriptor = NULL;


	int FileSize = file_size();

	gCodeData = (u1*)malloc(FileSize);
	if (NULL == gCodeData)
	{
		printf("�����ڴ�ʧ�ܣ�\n");
		return;
	}
	memset(gCodeData, 0, FileSize);

	//��ü���ָ������
	GetCodeData(gCodeData, FileSize);

	if (NULL == gCodeData)
	{
		printf("��ȡ����ָ�����ݳ�����\n");
		return;
	}

    for(u4 i=0; i<count; i++){
        classdef = dexGetClassDef(dexFile, i);

        descriptor = getTpyeIdString(dexFile, classdef->classIdx);

		if (strstr(descriptor,Tag) == NULL)
		{
			continue;
		}

		//����һЩϵͳ����
		if (strstr(descriptor, ClassTag) != NULL)
		{
			continue;
		}

        pEncodedData = dexFile->baseAddr + classdef->classDataOff;
        pClassData = dexReadAndVerifyClassData(&pEncodedData, NULL);

        if (pClassData == NULL) {
            continue;
        }

	  FixdexMethodInsns(dexFile, pClassData, descriptor);

    }

}

static void dumpDexCode(const DexCode *pCode)
{
    printf("      registers     : %d", pCode->registersSize);  
    printf("      ins           : %d", pCode->insSize); 
    printf("      outs          : %d", pCode->outsSize);   
    printf("      insns size    : %ld 16-bit code units", pCode->insnsSize);        

    int a = 0;        
    char buffer[256] = {0, 0};        
    char tmp[32];        
    
    for(u4 k=0; k<pCode->insnsSize; k++){          
        sprintf(tmp, "%04x ", pCode->insns[k]);        
        strcat(buffer, tmp);           
        if(k%8 == 7){              
        	printf("%s", buffer);
            buffer[0] = 0;         
        }        
    }    
    printf("%s", buffer);
}



static void handleDexMethod(DexClassData* classData, const char*method)
{
	// TODO
}

void* searchDexStart(const void *base)
{
	DexOptHeader *optHeader = (DexOptHeader*)base;


	return (void*)((u4)base + optHeader->dexOffset);
}

static bool checkDexMagic(const void *dexBase)
{
	const char *pattern = "dex\n035";
	const char *dexer = (const char *)dexBase;

	if(strcmp(dexer, pattern) == 0){
		return true;
	}

	return false;
}
