#include "Dec.h"
#include "crc32.h"
#include<stdio.h>


unsigned int PolyXorKey(DWORD crckey)
{
	unsigned int dwKey;
	char temp;
	unsigned __int8 temp1;
	unsigned __int8 temp2;
	char *pKey;
	int temp3;
	int j;
	int i;

	j = 0;
	temp3 = 0;
	pKey = (char *)&dwKey;
	temp2 = 0;
	temp1 = 0;
	temp = 0;
	dwKey = crckey ^ 0xDF138530;
	i = 0;
	while ( i <= 3 )
	{
		temp2 = *pKey;
		j = 128;
		temp3 = 7;
		while ( j > 1 )
		{
			temp = (temp2 & j / 2) >> (temp3 - 1);
			temp1 = ((signed int)(unsigned __int8)(temp2 & j) >> temp3) ^ temp;
			temp1 <<= temp3;
			temp2 |= temp1;
			j /= 2;
			--temp3;
		}
		temp = temp2 & 1;
		temp1 = temp2 & 1 ^ temp2 & 1;
		*pKey = temp2;
		++i;
		++pKey;
	}
	return dwKey;
}


//crc32 FE 00 00 20 = 0x200000FE  = 7C939E40
u1* DecCode(u1 *code, int codeSize, DWORD key, u1* oldData)
{

	unsigned long Polykey = 0;
	unsigned long crc2 = 0;

	u1 * tempcode = NULL;
	u1 * tempcode1 = NULL;

	if (NULL == code || 0 == codeSize || NULL == oldData)
	{
		return NULL;
	}

	tempcode = (u1*)malloc(codeSize);
	if (NULL == tempcode)
	{
		return NULL;
	}
	memset(tempcode, 0, codeSize);

	
	tempcode1 = oldData;
	DWORD CodeOffset = *(DWORD*)code;//�õ�����ָ��ƫ��



	tempcode1 += CodeOffset;//��λ������ָ�ʼλ��

	memcpy(tempcode, tempcode1, codeSize);

	crc2 = crc32(crc2, (unsigned char*)&key, 4);
	for (int j=0; j<codeSize; j++)
	{
		//ÿ4�ֽڽ��н���
		for (int i =0; i<4; i++)
		{
			tempcode[j+i] ^= *((unsigned char*)(&crc2)+i);

			tempcode[j+i] &= 0XFF;
			if (i==3)
			{
				Polykey = PolyXorKey(crc2);
				crc2 = Polykey;
			}
		}
		j += 3;
	}



	return tempcode;
	
}


int file_size()
{

	FILE * fp;

	if( (fp=fopen("data","rb")) == NULL )
	{
		printf("���ļ�ʧ��!\n");
		return NULL;
	}
	fseek(fp,0L,SEEK_END);
	int size=ftell(fp);
	fclose(fp);
	return size;
}

void GetCodeData( u1* outdata, int FileSize)
{
	FILE * fp;

	if (0 == FileSize || NULL == outdata)
	{
		return;
	}

	if( (fp=fopen("data","rb")) == NULL )
	{
		printf("���ļ�ʧ��!\n");
		return;
	}
	fread(outdata,FileSize,1,fp);
	fclose(fp);
	return;
}


int * XorArray(int *key, int codedata, int outcodedata, int codesize)
{
	int v4; // [sp+0h] [bp-24h]@1
	int v5; // [sp+4h] [bp-20h]@1
	int codedata1; // [sp+8h] [bp-1Ch]@1
	int *key1; // [sp+10h] [bp-14h]@1
	int *key2; // [sp+14h] [bp-10h]@1
	int keyindex; // [sp+18h] [bp-Ch]@1
	int i; // [sp+1Ch] [bp-8h]@1

	codedata1 = codedata;
	v5 = outcodedata;
	v4 = codesize;
	key1 = key;
	key2 = (int *)&key1;
	keyindex = 0;
	for ( i = 0; v4 > i; ++i )
	{
		key = key2;
		*(BYTE *)(v5 + i) = *(BYTE *)(codedata1 + i) ^ *((BYTE *)key2 + keyindex);
		if ( keyindex == 3 )
		{
			key = (int *)((int *(*)(unsigned int))PolyXorKey)((unsigned int)key1);
			key1 = key;
			keyindex = 0;
		}
		else
		{
			++keyindex;
		}
	}
	return key;
}

int XorArray_0x99(int key, int codedata, int outcodedata, int codelen)
{
	int v4; // [sp+10h] [bp-14h]@1
	int v5; // [sp+14h] [bp-10h]@1
	int *v6; // [sp+18h] [bp-Ch]@1
	int i; // [sp+1Ch] [bp-8h]@1

	v4 = key;
	v6 = &v4;
	v5 = 0;
	for ( i = 0; codelen > i; ++i )
		*(BYTE *)(outcodedata + i) = ~(*(BYTE *)(codedata + i) ^ 0x66);
	return key;
}

unsigned __int8 * dbone_crypt_ins(unsigned int DebugInfo1, unsigned __int8 *CodeData, unsigned int CodeLen, int Mode)
{
	int mode; // [sp+0h] [bp-1Ch]@1
	int codelen; // [sp+4h] [bp-18h]@1
	unsigned __int8 *codedata; // [sp+8h] [bp-14h]@1
	int DebugInfo; // [sp+Ch] [bp-10h]@1
	int crc2key; // [sp+14h] [bp-8h]@1

	DebugInfo = DebugInfo1;
	codedata = CodeData;
	codelen = CodeLen;
	mode = Mode;
	crc2key = crc32(crc2key, (unsigned char*)&DebugInfo, 4);;
	if ( mode == 1 )
	{
		XorArray(&crc2key, (int)codedata, (int)codedata, codelen);
	}
	else if ( mode )
	{
		puts("USAGE:dbone_crypt_ins(key,ins,ins_lenth)");
	}
	else
	{
		XorArray_0x99(DebugInfo, (int)codedata, (int)codedata, codelen);
	}
	return codedata;
}