#include <windows.h>
#include "dexFile.h"

unsigned int PolyXorKey(DWORD crckey);
u1* DecCode(u1 *code, int codeSize, DWORD key, u1* oldCode);
void GetCodeData( u1* outdata, int FileSize);

int file_size();

unsigned __int8 * dbone_crypt_ins(unsigned int DebugInfo1, unsigned __int8 *CodeData, unsigned int CodeLen, int Mode);
