//
// Created by beich on 2020/12/27.
//

#pragma once


extern "C" int canonicalize(const char *original, char *resolved, int len);