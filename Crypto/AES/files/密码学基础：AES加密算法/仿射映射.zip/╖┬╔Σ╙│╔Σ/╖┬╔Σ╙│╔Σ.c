# include "stdio.h"
# include "stdlib.h"




//�ҵ����λ
int GetHighestPosition(unsigned short Number)
{
	int i = 0;
	while (Number)
	{
		i++;
		Number = Number >> 1;
	}
	return i;
}


//GF(2^8)�Ķ���ʽ����
unsigned char Division(unsigned short Num_L, unsigned short Num_R, unsigned short *Remainder)
{
	unsigned short r0 = 0;
	unsigned char  q = 0;
	int bitCount = 0;

	r0 = Num_L;

	bitCount = GetHighestPosition(r0) - GetHighestPosition(Num_R);
	while (bitCount >= 0)
	{
		q = q | (1 << bitCount);
		r0 = r0 ^ (Num_R << bitCount);
		bitCount = GetHighestPosition(r0) - GetHighestPosition(Num_R);
	}
	*Remainder = r0;
	return q;
}



short Multiplication(unsigned char Num_L, unsigned char Num_R)
{
	//�������
	unsigned short Result = 0;		//٤�������ڳ˷�����Ľ��

	for (int i = 0; i < 8; i++)
	{
		Result ^= ((Num_L >> i) & 0x01) * (Num_R << i);
	}

	return Result;
}

int EEA_V2(int r0, int r1)
{
	int mod = r0;
	int r = 0;
	int t0 = 0;
	int t1 = 1;
	int t = t1;
	int q = 0;

	if (r1 == 0)
	{
		return 0;
	}

	while (r1 != 1)
	{
		//q = r0 / r1;
		q = Division(r0, r1, &r);

		r = r0 ^ Multiplication(q, r1);

		t = t0 ^ Multiplication(q, t1);

		r0 = r1;
		r1 = r;
		t0 = t1;
		t1 = t;
	}

	if (t < 0)
	{
		t = t ^ mod;
	}

	return t;
}

unsigned char ByteImage(int imput)
{
	unsigned char Result = 0;

	for (int i = 0; i < 8; i++)
	{
		Result ^= (((imput >> i) & 1) ^ ((imput >> ((i + 4) % 8)) & 1) ^ ((imput >> ((i + 5) % 8)) & 1) ^ ((imput >> ((i + 6) % 8)) & 1) ^ ((imput >> ((i + 7) % 8)) & 1)) << i;
	}

	Result = Result ^ 0x63;

	return Result;
}


int main()
{
	printf("��ӡ�����������ݣ�");
	for (int i = 0; i < 0x100; i++)
	{
		if (i % 16 == 0)
		{
			printf("\n");
		}
		printf("%02X ", i);

	}
	printf("\n\n��ӡ���ĳ˷���Ԫ:");

	for (int i = 0; i < 0x100; i++)
	{
		if (i % 16 == 0)
		{
			printf("\n");
		}
		printf("%02X ", EEA_V2(0x11B, i));

	}


	printf("\n\n��ӡ����S��:\n");
	for (int i = 0; i < 16; i++)
	{
		for (int j = 0; j < 16; j++)
		{
			unsigned int num = 16 * i + j;
			printf("%02X ", ByteImage(EEA_V2(0x11B, num)));
		}
		printf("\n");
	}


	system("pause");
	return 0;
}